from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, PasswordField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class EditForm(FlaskForm):
    card = StringField('Номер карты', validators=[DataRequired()])
    cvc = PasswordField("CVC")
    submit = SubmitField('Применить')