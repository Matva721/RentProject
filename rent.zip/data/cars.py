import datetime
import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase

class Cars(SqlAlchemyBase):
    __tablename__ = 'cars'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    car_brand = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    car_model = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    img = sqlalchemy.Column(sqlalchemy.BLOB)
    year = sqlalchemy.Column(sqlalchemy.Integer)
    price = sqlalchemy.Column(sqlalchemy.Integer)
    car_class = sqlalchemy.Column(sqlalchemy.String)
    number_seats = sqlalchemy.Column(sqlalchemy.Integer)
    img_vnut1 = sqlalchemy.Column(sqlalchemy.BLOB)
    img_vnut2 = sqlalchemy.Column(sqlalchemy.BLOB)
    wheel = sqlalchemy.Column(sqlalchemy.String)
    city = sqlalchemy.Column(sqlalchemy.String)